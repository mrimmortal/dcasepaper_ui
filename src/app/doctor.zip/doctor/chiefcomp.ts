export interface ChiefComp{
    id: number,
    date: Date,
    complain: string
}