import { Component, OnInit,HostListener } from '@angular/core';
import {ChiefComp} from './chiefcomp'
import { MatDialog } from '@angular/material';
import hotkeys from 'hotkeys-js';
import { MyprofileComponent } from '../myprofile/myprofile.component';
import { HttpClient } from '@angular/common/http';
export enum KEY_CODE {
  
  RIGHT_ARROW = 80,
  LEFT_ARROW = 37
}
@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']
})
export class DoctorComponent implements OnInit {

  opened = false;
  
  @HostListener('window:keyup', ['$event'])
  keyEvent(event: KeyboardEvent) {
    if (event.shiftKey && event.which === KEY_CODE.RIGHT_ARROW) {
      this.openDialog();
    }
  }

  constructor(private http: HttpClient ,public dialog: MatDialog) { }

  ngOnInit() {
  }
  
  openDialog(): void {
    const dialogRef = this.dialog.open(MyprofileComponent, {
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      // opened = false;
  
    });
  }


 
  WorkDoneSettings = {
    // delete: {
    //   confirmDelete: true,

    //   deleteButtonContent: 'Delete data',
    //   saveButtonContent: 'save',
    //   cancelButtonContent: 'cancel'
    // },
    // add: {
    //   confirmCreate: true,
    // },
    // edit: {
    //   confirmSave: false,
    // },
        columns: {
      id: {
        title: 'ID',
        filter:false,
        width:'100px'
      }, 
      date: {
        title: 'Date',
     
        width: '250px',
        filter: false,
        sortDirection: 'desc',
        editor: {
          type: 'custom',
   
        }
      },
      treatDOne: {
        title: 'Treatment Done',
        filter:false,
        
      },
      details: {
        title: 'Details',
        filter:false,
        
      },
      treatadv: {
        title: 'Treatment Advised',
        filter:false,
        
      },
      paid: {
        title: 'Paid',
        filter:false,
        
      },
      balnce: {
        title: 'Balance',
        filter:false,
        
      },
      prescriptions: {
        title: 'Prescriptions',
        filter:false,
        
      },bill: {
        title: 'Bill',
        filter:false,
        
      }
    },
    attr: {
      class: 'table table-bordered'
    },
    actions: {
      add: true,
      edit: true,
      delete:true,
      },
  };
workdoneData=[];

  chiefsettings = {
    delete: {
      confirmDelete: true,

      deleteButtonContent: 'Delete data',
      saveButtonContent: 'save',
      cancelButtonContent: 'cancel'
    },
    add: {
      confirmCreate: true,
    },
    edit: {
      confirmSave: false,
    },
        columns: {
      id: {
        title: 'ID',
        filter:false,
        width:'100px'
      }, 
      date: {
        title: 'Date',
     
        width: '250px',
        filter: false,
        sortDirection: 'desc',
        editor: {
          type: 'custom',
        
        }
      },
      chefi: {
        title: 'Chief Complaints',
        filter:false,
        
      }
    },
    attr: {
      class: 'table table-bordered'
    },
    actions: {
      add: true,
      edit: true,
      delete:true,
      },
  };
  chefidata = [
    {
      id: 1,
      date: "2019-08-14T00:45:51",
      chefi:"safg"
      
    },
    {
      id: 2,
      date: "2019-08-14T00:45:51",
    }
  ];

  onDeleteConfirm(event) {
    console.log("Delete Event In Console")
    console.log(event);
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }

  onCreateConfirm(event) {
    if (window.confirm('Are you sure you want to to Create?')) {
   
      var data = {"id" : event.newData.id,
                "date" : event.newData.Date,
                "Compalin" : event.newData.chefi
                };
                
	this.http.post<ChiefComp>('http://dagduteli.com/distri/AngaulrReport/demo/add.php', data).subscribe(
        res => {
          alert(res);
          console.log(res);
          event.confirm.resolve(event.newData);
      },err => console.log(err)
      );
     
    
     }   }
  onSaveConfirm(event) {
    console.log("Edit Event In Console")
    console.log(event);
  }
  
}
